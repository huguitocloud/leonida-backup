//! The `VICTORY_*` on/off switches (`VICTORY_D3D12_DEBUG=1` and its siblings).

use std::ffi::OsStr;

/// Whether a switch's value turns it on: it is set, and is not `0`.
///
/// A switch used to be on whenever its variable existed, so `VICTORY_D3D12_WARP=0` (typed to switch it off, or left
/// over from comparing two runs) still selected the software adapter. Any other value keeps the old meaning.
fn value_is_on(value: Option<&OsStr>) -> bool {
    value.is_some_and(|v| v != "0")
}

/// Whether the environment variable `name` switches something on.
pub(crate) fn on(name: &str) -> bool {
    value_is_on(std::env::var_os(name).as_deref())
}

/// A switch that is on unless its variable is `0`, read once; with
/// `VICTORY_AB` naming it (diagnostics builds, `crate::ab`), on and off while
/// the title runs.
#[cfg(windows)]
#[macro_export]
#[doc(hidden)]
macro_rules! toggled {
    ($name:literal) => {{
        #[cfg(feature = "diagnostics")]
        {
            static BIT: std::sync::OnceLock<Result<bool, u32>> = std::sync::OnceLock::new();
            match BIT.get_or_init(|| match $crate::ab::bit($name) {
                Some(bit) => Err(bit),
                None => Ok(std::env::var_os($name).is_none_or(|v| v != "0")),
            }) {
                Ok(on) => *on,
                Err(bit) => $crate::ab::on(*bit),
            }
        }
        #[cfg(not(feature = "diagnostics"))]
        {
            static ON: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
            *ON.get_or_init(|| std::env::var_os($name).is_none_or(|v| v != "0"))
        }
    }};
}

/// A switch that is off unless its variable is `1`, read once; with
/// `VICTORY_AB` naming it (diagnostics builds), on and off while the title
/// runs.
#[cfg(windows)]
#[macro_export]
#[doc(hidden)]
macro_rules! asked_for {
    ($name:literal) => {{
        static ASKED: std::sync::OnceLock<Result<bool, u32>> = std::sync::OnceLock::new();
        let asked = ASKED.get_or_init(|| {
            #[cfg(feature = "diagnostics")]
            if let Some(bit) = $crate::ab::bit($name) {
                return Err(bit);
            }
            Ok(std::env::var_os($name).is_some_and(|v| v == "1"))
        });
        match *asked {
            Ok(on) => on,
            #[cfg(feature = "diagnostics")]
            Err(bit) => $crate::ab::on(bit),
            #[cfg(not(feature = "diagnostics"))]
            Err(_) => false,
        }
    }};
}

#[cfg(test)]
mod tests {
    use super::value_is_on;
    use std::ffi::OsStr;

    #[test]
    fn unset_is_off() {
        assert!(!value_is_on(None));
    }

    #[test]
    fn zero_is_off() {
        assert!(!value_is_on(Some(OsStr::new("0"))));
    }

    #[test]
    fn one_is_on() {
        assert!(value_is_on(Some(OsStr::new("1"))));
    }

    #[test]
    fn other_values_keep_their_old_meaning() {
        // Documented as `=1`; anything else that was on before stays on: only `0` is new.
        for value in ["", "true", "yes", "2", "00", " 0", "0 "] {
            assert!(value_is_on(Some(OsStr::new(value))), "{value:?}");
        }
    }
}
