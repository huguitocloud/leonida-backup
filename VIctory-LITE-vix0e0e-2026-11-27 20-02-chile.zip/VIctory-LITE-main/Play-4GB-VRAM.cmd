@echo off
setlocal EnableExtensions DisableDelayedExpansion

if not defined VICTORY_GAME_DIR set "VICTORY_GAME_DIR=%~dp0..\GTA6.Xbox.v1.0.2.1"
if not exist "%VICTORY_GAME_DIR%\game_scarlett_master.exe" (
  echo Set VICTORY_GAME_DIR to your own Xbox dump folder containing game_scarlett_master.exe. 1>&2
  echo Example: 1>&2
  echo   set "VICTORY_GAME_DIR=D:\Games\MyDump" 1>&2
  echo   Play-4GB-VRAM.cmd 1>&2
  exit /b 2
)

set "runner=%~dp0target\release\victory.exe"
if not exist "%runner%" (
  echo Built binary not found at "%runner%". 1>&2
  echo Build it first with: cargo build --release -p victory 1>&2
  exit /b 2
)

if not defined VICTORY_CACHE_DIR set "VICTORY_CACHE_DIR=%LOCALAPPDATA%\VIctory\cache-pareto"

rem --- Display & Render Scale (1080p native menus/loading, 960x540 3D scene) ---
if not defined VICTORY_DISPLAY_MODE set "VICTORY_DISPLAY_MODE=1920x1080"
if not defined VICTORY_RENDER_SCALE set "VICTORY_RENDER_SCALE=0.5"
if not defined VICTORY_OWN_UPSCALER set "VICTORY_OWN_UPSCALER=1"

rem --- 4 GB VRAM & 16 GB RAM Budget / Fragmentation Control ---
if not defined VICTORY_TEXTURE_MAX_DIM set "VICTORY_TEXTURE_MAX_DIM=512"
if not defined VICTORY_TEXTURE_MAX_DIM_AUX set "VICTORY_TEXTURE_MAX_DIM_AUX=256"
if not defined VICTORY_TEXTURE_DROP_MIPS set "VICTORY_TEXTURE_DROP_MIPS=0"
if not defined VICTORY_TEXTURE_PRESSURE_CAP set "VICTORY_TEXTURE_PRESSURE_CAP=1"
if not defined VICTORY_TEXTURE_ROOM_PERCENT set "VICTORY_TEXTURE_ROOM_PERCENT=94"
if not defined VICTORY_CARD_ROOM_FOR_TARGETS_MB set "VICTORY_CARD_ROOM_FOR_TARGETS_MB=1024"
if not defined VICTORY_CARD_BUFFERS_MB set "VICTORY_CARD_BUFFERS_MB=256"
if not defined VICTORY_CARD_BUFFERS_MIN_KB set "VICTORY_CARD_BUFFERS_MIN_KB=64"
if not defined VICTORY_CARD_WINDOWS_MB set "VICTORY_CARD_WINDOWS_MB=0"
if not defined VICTORY_MEMORY_CARD_MB set "VICTORY_MEMORY_CARD_MB=0"
if not defined VICTORY_WINDOW_KB set "VICTORY_WINDOW_KB=1024"
if not defined VICTORY_WINDOW_IDLE_MS set "VICTORY_WINDOW_IDLE_MS=2500"
if not defined VICTORY_SEND_SPARE_MB set "VICTORY_SEND_SPARE_MB=32"
if not defined VICTORY_POOL_BLOCK_MB set "VICTORY_POOL_BLOCK_MB=4"
if not defined VICTORY_TARGET_SWEEP set "VICTORY_TARGET_SWEEP=1"
if not defined VICTORY_KEEP_FREED set "VICTORY_KEEP_FREED=0"
if not defined VICTORY_BURY_LAG set "VICTORY_BURY_LAG=8"
if not defined VICTORY_RIPE_BLOCKS set "VICTORY_RIPE_BLOCKS=0"

rem --- Fast Scene & Texture Streaming ---
if not defined VICTORY_TEXTURE_STAGE_MB set "VICTORY_TEXTURE_STAGE_MB=256"
if not defined VICTORY_TEXTURE_STAGE_MS set "VICTORY_TEXTURE_STAGE_MS=450"
if not defined VICTORY_EARLY_TEXTURES_MS set "VICTORY_EARLY_TEXTURES_MS=35"
if not defined VICTORY_MAP_THREADS set "VICTORY_MAP_THREADS=auto"
if not defined VICTORY_UPLOAD_AHEAD set "VICTORY_UPLOAD_AHEAD=1"
if not defined VICTORY_SHOW_AFTER set "VICTORY_SHOW_AFTER=1"
if not defined VICTORY_LEVELS_ON_DEMAND set "VICTORY_LEVELS_ON_DEMAND=0"
if not defined VICTORY_TEXTURE_NO_WAIT set "VICTORY_TEXTURE_NO_WAIT=1"
if not defined VICTORY_TEXTURE_BACK set "VICTORY_TEXTURE_BACK=1"

rem --- Pipeline, Submission & Non-RT GPU Stability ---
if not defined VICTORY_NO_WATCHDOG set "VICTORY_NO_WATCHDOG=1"
if not defined VICTORY_BVH_MISS set "VICTORY_BVH_MISS=1"
if not defined VICTORY_PIPELINE_WAIT_MS set "VICTORY_PIPELINE_WAIT_MS=5000"
if not defined VICTORY_DYNAMIC_SLOTS set "VICTORY_DYNAMIC_SLOTS=524288"
if not defined VICTORY_RELAY set "VICTORY_RELAY=2"
if not defined VICTORY_CARD_STEPS set "VICTORY_CARD_STEPS=2"
if not defined VICTORY_WIDE_BACK set "VICTORY_WIDE_BACK=1"
if not defined VICTORY_CARD_REHASH_RUNS set "VICTORY_CARD_REHASH_RUNS=1"
if not defined VICTORY_JOIN_COPIES set "VICTORY_JOIN_COPIES=1"
if not defined VICTORY_INDIRECT_WINDOW set "VICTORY_INDIRECT_WINDOW=1"
if not defined VICTORY_RELAY_COPY set "VICTORY_RELAY_COPY=1"
if not defined VICTORY_INDIRECT_BATCH set "VICTORY_INDIRECT_BATCH=2"
if not defined VICTORY_CARD_AWAKE set "VICTORY_CARD_AWAKE=1"
if not defined VICTORY_WC_NO_BACK set "VICTORY_WC_NO_BACK=1"
if not defined VICTORY_WC_NO_BACK_MIN_KB set "VICTORY_WC_NO_BACK_MIN_KB=1024"
if not defined VICTORY_THIN set "VICTORY_THIN=1"
if not defined VICTORY_JOIN_PARTS set "VICTORY_JOIN_PARTS=8"
if not defined VICTORY_PORT_CONSTANTS set "VICTORY_PORT_CONSTANTS=1"
if not defined VICTORY_KBM_GTA set "VICTORY_KBM_GTA=1"
if not defined VICTORY_HELPER_PRIORITY set "VICTORY_HELPER_PRIORITY=1"
if not defined VICTORY_RAW_VIEW_CLAMP set "VICTORY_RAW_VIEW_CLAMP=1"
if not defined VICTORY_PANEL set "VICTORY_PANEL=1"
if not defined VICTORY_VRAM_STATS set "VICTORY_VRAM_STATS=1"
if not defined VICTORY_SKIP_PIPELINES set "VICTORY_SKIP_PIPELINES=02384a60fda6f2d0,731a39171b568298"

rem --- Non-RT Lighting / Ambient Fill ---
if not defined VICTORY_AMBIENT set "VICTORY_AMBIENT=1.4"
if not defined VICTORY_AMBIENT_FLOOR set "VICTORY_AMBIENT_FLOOR=1.2"
if not defined VICTORY_AMBIENT_SHADE set "VICTORY_AMBIENT_SHADE=0.5,0.5"
if not defined VICTORY_AMBIENT_AIR set "VICTORY_AMBIENT_AIR=2.0"
if not defined VICTORY_AMBIENT_MOST set "VICTORY_AMBIENT_MOST=3"
if not defined VICTORY_AMBIENT_SPECULAR set "VICTORY_AMBIENT_SPECULAR=1.0"
if not defined VICTORY_SHADOW_LIFT set "VICTORY_SHADOW_LIFT=1.2"

if not defined VICTORY_LOG if not defined RUST_LOG set "VICTORY_LOG=warn"

"%runner%" run "%VICTORY_GAME_DIR%\game_scarlett_master.exe" --console series-s --execute
exit /b %errorlevel%
