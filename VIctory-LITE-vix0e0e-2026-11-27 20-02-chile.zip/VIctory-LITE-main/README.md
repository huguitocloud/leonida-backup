# VIctory LITE

A lightweight community fork of [VIctory](https://github.com/Marvisak/VIctory) (built on top of `codec-d/cool_fox`, `avatarmanz/VIctory-7900XTX`, `fxceless/victory-fork`, `Belobug/VIctory-Belobug-AMD`, and `crossducking/RAZDA4A-XEN`) specifically tuned to run on **4 GB VRAM GPUs and 16 GB RAM** (tested on **NVIDIA GTX 1650 4 GB + Ryzen 5 5500 + 16 GB DDR4** with Windows 10 and an SSD pagefile).

**This repository contains no game files, code, or assets.** You need your own legally obtained copy/dump of the title. It is not affiliated with or endorsed by the game's developer or publisher.

## What this 4 GB VRAM fork adds

* **Native 1080p menus & loading screens with scaled 3D rendering:** keeps Plane 1 UI/menus/loading artwork uncapped (`world_targets_active()` threshold at 280 MiB in `resource.rs` + `VICTORY_DISPLAY_MODE=1920x1080`) while scaling the 3D scene (`VICTORY_RENDER_SCALE=0.5`, `960x540`) and avoiding the `1280x720` display-mode trap.
* **Smart BC texture mip capping & dynamic VRAM pressure control:** `VICTORY_TEXTURE_MAX_DIM=512` for BC world textures, `VICTORY_TEXTURE_MAX_DIM_AUX=256` for BC4/BC5 normal/mask maps, and `VICTORY_TEXTURE_PRESSURE_CAP=1` dynamic step-down at `>= 90%` VRAM, skipping non-BC UI/HUD and non-power-of-two banners.
* **Reduced WDDM `SHARED` GPU memory & RAM footprint** (incorporating audited ports from `crossducking/RAZDA4A-XEN`):
  * `CardCpu::Cpu(Box<[u8]>)` host-heap CPU backing for card buffers (`shadow.rs`).
  * Configurable `VICTORY_SEND_SPARE_MB` (`send.rs`, set to `32` MiB) and fast idle window eviction (`VICTORY_WINDOW_IDLE_MS=2500` + 2 s eviction at `SHARED >= 70%`).
  * `shared_twin_scratch()` (upstream `#2162`), `typed_store` descriptor check (upstream `#2462`), and `VirtualAlloc(..., MEM_RESET)` in `XMemFreePhysicalPages`.
  * Async `victory-sweep` and `victory-bury` low-priority background threads (`host.rs`).
* **Low-fragmentation VRAM pool & fast scene streaming (anti pop-in):**
  * `VICTORY_POOL_BLOCK_MB=4` (4 MiB texture pool blocks) to cut trapped free holes in 4 GB VRAM without committed-resource fence stalls.
  * 4 Copy-Queue upload-ahead workers (`texture/ahead.rs`, 64 MiB in-flight, 24 MiB / 128-texture batches), `16,384`-slot scan window per pass, ~1.4 s retry cap on partially-mapped slots (`draw.rs`), `128 MiB / 35 ms` early pre-draw upload pass, and adaptive `VICTORY_MAP_THREADS=auto`.

## Quick start (4 GB VRAM / 16 GB RAM)

Install the pinned Rust toolchain and MSVC C++ Build Tools (with Windows SDK), build in release mode, and run the included 4 GB VRAM launcher:

```powershell
cargo build --release -p victory
$env:VICTORY_GAME_DIR = 'D:\Games\MyDump'
.\Play-4GB-VRAM.cmd
```

*(Note: on 16 GB RAM systems, a 24–32 GB pagefile on an SSD is strongly recommended.)*

---

## Upstream README (`codec-d/cool_fox` & `avatarmanz/VIctory-7900XTX`)

### Run the codec_d Windows build

Download and extract the Windows x64 ZIP from the [private releases](https://github.com/codec-d/cool_fox/releases/latest). Open PowerShell in the extracted folder and point the launcher at your own complete Xbox dump.

```powershell
$env:VICTORY_GAME_DIR = 'D:\Games\MyDump'
.\Play-VIctory.cmd pareto-residency
```

The launcher selects Series S and the RTX-tested residency settings. It builds its shader cache locally under `%LOCALAPPDATA%\VIctory\cache-pareto`. Set `VICTORY_CACHE_DIR` to reuse an existing cache outside the checkout. Windows x64, an AVX2 CPU, and a Direct3D 12 GPU with shader model 6.6 and mesh shader support are required.

To build from this checkout, install the pinned Rust toolchain and the MSVC C++ build tools with a Windows SDK, then run `cargo build --release --locked -p victory`. The same launcher finds `target\release\victory.exe`. The sections below describe the upstream AMD fork and its separate launcher.

A fork of [VIctory](https://github.com/Marvisak/VIctory), a compatibility layer
that runs an Xbox Series title natively on Windows from files the user supplies.
This one is about **speed on AMD RDNA 3**: the world at 30 frames a second on
one PC, without giving up the picture. It is not there yet.

**This repository contains no game files, code or assets.** You need your own
copy of the game. It is not affiliated with or endorsed by the game's developer
or publisher.

## Where it stands (2026-11-25)

Tested on one machine only: Windows 11, Intel i9-12900K, 64 GB RAM, Radeon
RX 7900 XTX, 1440p, the Series X profile.

| | |
|---|---|
| Menus, videos, loading screens | 30 fps |
| Prologue, indoors | 50-75 ms a frame (13-20 fps) |
| First mission with the boat | 46-53 ms (19-22 fps) |
| Street chase with many cars and people | 100-165 ms (6-10 fps), single frames far longer |
| Outdoors on foot, the camp | 60-90 ms |
| Flying | 42-57 ms |
| Longest session so far | 41 minutes, no crash |
| Memory | 40-46 GB of private memory: **64 GB of RAM recommended** |

It started at 280 ms a frame in the same scenes two days earlier.

What is known to be wrong:

- Trees, plants and far buildings flicker outdoors in some places.
- Rooms with little direct light are too dark without `-RayTracing`.
- Textures of what just came into view appear late while the title streams.
- The first run with a new driver or a new build stutters while the driver makes
  pipelines (`victory warm` makes them ahead).
- Recording a frame in the world makes the title's own watchdog end it.

## How to run it

You need Windows 10/11 x64, a CPU with AVX2, a Direct3D 12 GPU with shader
model 6.6 and mesh shaders, Rust (the toolchain is pinned), the MSVC build
tools, and your own dump of the title.

```powershell
git clone https://github.com/avatarmanz/VIctory-7900XTX
cd VIctory-7900XTX
copy victory.example.toml victory.toml      # then set your paths, outside this folder
cargo build --locked --profile diag -p victory --features diagnostics
scripts\play.ps1 -Exe <path of your copy's executable>
```

`scripts\play.ps1 -Safe` leaves out the newest, faster ways; try it first when
something is wrong. `-RayTracing` turns the title's ray-traced indirect light on.

Before the first run, ahead of time (both can be stopped and go on later):

```powershell
target\diag\victory.exe shaders <the shader archives>   # every shader translated, minutes
target\diag\victory.exe warm --used                     # pipelines earlier runs drew with, for a new driver or build
```

Commands, debugging switches and upstream's own description:
[docs/README-fxceless.md](docs/README-fxceless.md). Every `VICTORY_...` switch is
described in a comment where it is read.

## What is different here

In short; the reasons and the measurements are in [docs/findings.md](docs/findings.md).

- **List calls are written down, not carried out, on the title's threads**
  (`VICTORY_THIN`): eight threads of ours translate them.
- **Submissions are prepared by a thread of ours and joined**
  (`VICTORY_ASYNC_SUBMIT`, `VICTORY_JOIN_PARTS`), with what can be spread over
  threads spread: refreshes, compares (AVX2), descriptor records, landings.
- **What shaders wrote comes back beside the write guards**, by the dwords that
  changed, on a thread of its own (`VICTORY_RELAY`, `VICTORY_LAND`).
- **Buffer fills that need bytes still on the card are done on the card**
  (`VICTORY_CARD_STEPS`) instead of waiting for it.
- **The title's writes are caught more cheaply**: one view opened at a fault,
  blocks that rest, places in the title's code that look before they write.
- **Textures go up on a copy queue of their own** and a slot shows one only after
  its upload ran, which also ended a device loss that came every 15 minutes or so.
- **Boats float**: textures that shaders write and the title's CPU reads go back
  to title memory (from fxceless and Geckomacabre, on by default here).
- **Frame record and replay** with per-pass times and shader variants compared
  turn by turn ([docs/replay.md](docs/replay.md)).

## Credits

This is a tree of other people's work with more on top. The history is kept, and
commits taken from elsewhere name the commit and its author.

- **[VIctory](https://github.com/Marvisak/VIctory)** by Marvisak and its
  contributors: the loader, the runtime services, the Direct3D 12 back end and
  the shader recompiler.
- **[codec-d/cool_fox](https://github.com/codec-d/cool_fox)** (`codec_d`): the
  Windows `pareto-residency` fork this repository directly builds upon.
- **[avatarmanz/VIctory-7900XTX](https://github.com/avatarmanz/VIctory-7900XTX)**:
  upstream AMD RDNA 3 performance fork (`VICTORY_THIN`, async submit, copy-queue
  uploads, relay/land).
- **[crossducking/RAZDA4A-XEN](https://github.com/crossducking/RAZDA4A-XEN)**
  (`RAZDA4A XEN`): `CardCpu::Cpu` host-heap backing, async `victory-sweep` /
  `victory-bury` threads, `VirtualAlloc(MEM_RESET)` physical page discard,
  `VICTORY_SEND_SPARE_MB`, `VICTORY_WINDOW_IDLE_MS`, `shared_twin_scratch`, and
  upstream `#2462` descriptor fix.
- **[fxceless/victory-fork](https://github.com/fxceless/victory-fork)**
  (`Hyphen`): the fork this family started from, and the people whose pull
  requests it carries.
- **[DexNom/VIctory](https://github.com/DexNom/VIctory)**: ray tracing fixes,
  cube gradients, sparse textures.
- **[Belobug/VIctory-Belobug-AMD](https://github.com/Belobug/VIctory-Belobug-AMD)**:
  the ambient light idea, pipeline workers, and work by romainhedouin.
- **[FQY55kai/ZJOU-VICTORY](https://github.com/FQY55kai/ZJOU-VICTORY)**.
- **[myokex/victory-amd](https://github.com/myokex/victory-amd)**: the guard over
  every view of a page (with Spexivus, joroyt and tightfall), and Joshua Odom's
  reads into title memory.
- **Geckomacabre** and **cxy0072019-sketch**: the texture read-back.
- **[XCL](https://github.com/ivall/xcl)** (GPL-2.0-only) was read for how the same
  title behaves under another layer; no code of it is here.
- This fork's changes were made with [Claude Code](https://claude.com/claude-code).

## License

GPL-3.0-or-later, as VIctory. See [LICENSE](LICENSE); the one file that is not
covered is named in [docs/asset-policy.md](docs/asset-policy.md).
