; Narrow integer typed buffers: 8/16-bit UINT and SINT formats 5, 6, 11, 12, 18, 19, 28, 61 and 70.
; Lane 0 writes the source dwords 0x7f01ff80 0x8000ffff 0x12345678 0x9abcdef0 at byte 0x200, then:
; out[0..35]: buffer_load_format_xyzw with DST_SEL XYZW, four words per format in the order above;
; out[36..43]: DST_SEL X011 for 8_SINT and 16_UINT (0 and integer 1);
; out[44..49]: buffer_load_format_d16_xyzw for 8_SINT, 8_8_8_8_SINT and 16_16_16_16_SINT;
; out[64..81]: buffer_store_format_xyzw of 0x7f, 0x80, -128, -129 (8-bit formats) or 0x7fff, 0x8000, -32768,
;   -32769 (16-bit) at a dword pair per format, with the runtime's selectors (X001, XY01, XYZW); SINT clamps
;   signed, UINT saturates, and a 1-2 byte element keeps the 0xee fill of the rest of its dword.
; The expected words (check.py FMT_INT_NARROW_WORDS) are this program's output on gfx1036, run natively.
v_cmpx_eq_u32_e32 0, v0
v_mov_b32_e32 v1, 0x7f01ff80
v_mov_b32_e32 v2, 0x8000ffff
v_mov_b32_e32 v3, 0x12345678
v_mov_b32_e32 v4, 0x9abcdef0
v_mov_b32_e32 v5, 0x200
buffer_store_dwordx4 v[1:4], v5, s[0:3], 0 offen
s_waitcnt_vscnt null, 0x0
s_mov_b32 s4, s0
s_mov_b32 s5, s1
s_mov_b32 s6, s2
s_mov_b32 s7, 0x31005fac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x0
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x31006fac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x10
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x3100bfac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x20
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x3100cfac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x30
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x31012fac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x40
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x31013fac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x50
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x3101cfac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x60
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x3103dfac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x70
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x31046fac
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x80
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x31006244
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0x90
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x3100b244
buffer_load_format_xyzw v[8:11], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0xa0
buffer_store_dwordx4 v[8:11], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x31006fac
buffer_load_format_d16_xyzw v[8:9], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0xb0
buffer_store_dwordx2 v[8:9], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x3103dfac
buffer_load_format_d16_xyzw v[8:9], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0xb8
buffer_store_dwordx2 v[8:9], v6, s[0:3], 0 offen
s_mov_b32 s7, 0x31046fac
buffer_load_format_d16_xyzw v[8:9], v5, s[4:7], 0 offen
s_waitcnt vmcnt(0)
v_mov_b32_e32 v6, 0xc0
buffer_store_dwordx2 v[8:9], v6, s[0:3], 0 offen
v_mov_b32_e32 v12, 0x7f
v_mov_b32_e32 v13, 0x80
v_mov_b32_e32 v14, 0xffffff80
v_mov_b32_e32 v15, 0xffffff7f
v_mov_b32_e32 v16, 0x7fff
v_mov_b32_e32 v17, 0x8000
v_mov_b32_e32 v18, 0xffff8000
v_mov_b32_e32 v19, 0xffff7fff
s_mov_b32 s7, 0x31005204
v_mov_b32_e32 v6, 0x100
buffer_store_format_xyzw v[12:15], v6, s[4:7], 0 offen
s_mov_b32 s7, 0x31006204
v_mov_b32_e32 v6, 0x108
buffer_store_format_xyzw v[12:15], v6, s[4:7], 0 offen
s_mov_b32 s7, 0x3100b204
v_mov_b32_e32 v6, 0x110
buffer_store_format_xyzw v[16:19], v6, s[4:7], 0 offen
s_mov_b32 s7, 0x3100c204
v_mov_b32_e32 v6, 0x118
buffer_store_format_xyzw v[16:19], v6, s[4:7], 0 offen
s_mov_b32 s7, 0x3101222c
v_mov_b32_e32 v6, 0x120
buffer_store_format_xyzw v[12:15], v6, s[4:7], 0 offen
s_mov_b32 s7, 0x3101322c
v_mov_b32_e32 v6, 0x128
buffer_store_format_xyzw v[12:15], v6, s[4:7], 0 offen
s_mov_b32 s7, 0x3101c22c
v_mov_b32_e32 v6, 0x130
buffer_store_format_xyzw v[16:19], v6, s[4:7], 0 offen
s_mov_b32 s7, 0x3103dfac
v_mov_b32_e32 v6, 0x138
buffer_store_format_xyzw v[12:15], v6, s[4:7], 0 offen
s_mov_b32 s7, 0x31046fac
v_mov_b32_e32 v6, 0x140
buffer_store_format_xyzw v[16:19], v6, s[4:7], 0 offen
s_endpgm
